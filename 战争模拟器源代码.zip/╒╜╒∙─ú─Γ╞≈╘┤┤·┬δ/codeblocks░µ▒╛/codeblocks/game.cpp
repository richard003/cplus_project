#include "game.h"
#include<iostream>
using namespace std;
void showmap(void)
{
	int i, j;
	for (i = 0; i < Hight; i++)
	{
		for (j = 0; j < Wight; j++)
		{
			if (map[i][j] != 1)
				cout << map[i][j] << " ";
			else
				cout << '*' << " ";
		}
		cout << endl;
	}
}
