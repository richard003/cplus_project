#include "enemy.h"
int enemy::number = Enemynumber;
enemy enemies[Enemynumber];
extern char map[Hight][Wight];
void enemy::set_pos(int x, int y)
{
	position.first = x;
	position.second = y;
}
void enemy::set_pos(P pos)
{
	position = pos;
}
P enemy::get_pos(void)
{
	return position;
}
bool operator==(P pos1, P pos2)
{
	if (pos1.first == pos2.first && pos1.second == pos2.second)
		return true;
	else
		return false;
}
enemy* find(P pos)
{
	int i;
	for (i = 0; i < Enemynumber; i++)
	{
		if (pos == enemies[i].get_pos())
		{
			return &enemies[i];
		}
	}
	cout << "Unexpected eorre! Cannot find the enemy!";
	exit(1);
}
enemy::enemy(int x,int y,double damage, double health)
{
	this->damage = damage;
	this->health = health;
	position.first = x;
	position.second = y;
}
void enemy::set_able(int damage, int health)
{
	this->damage = damage;
	this->health = health;
}
void enemy::set_level(int n)
{
	level = n;
}
void set_enemies(void)
{
	int i, j;
	int n = 0;
	for (i = 0; i < Hight; i++)
	{
		for (j = 0; j < Wight; j++)
		{
			if (map[i][j]>='a'&&map[i][j]<='z')
			{
				enemies[n].set_pos(i, j);
				enemies[n].set_level(map[i][j]-'a'+1);
				enemies[n].set_able((map[i][j]-'a'+1) * Enemy_oringnal_damage, (map[i][j]-'a'+1) * Enemy_oringnal_health);
				n++;
			}
		}
	}
}
