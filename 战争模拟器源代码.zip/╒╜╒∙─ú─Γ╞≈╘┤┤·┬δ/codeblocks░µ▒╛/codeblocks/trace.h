
#pragma once
#include<iostream>
using namespace std;
//���ֱ�ʾ���˵ĵȼ���0��ʾû�е���/���˵ĵȼ�Ϊ0��
#define Wight 5
#define Hight 5
extern char map[Hight][Wight];
extern char actiontype[][20];
class trace
{
	double health;
	double damage;
	int level;
	int action;
	int bout;
public:
	trace() { health = action = damage = level = action = bout = 0; }
	trace(double health,double damage,int level,int action,int bout);
	void show_trace();
	void set_information(double health, double damage, int level, int action, int bout);
	friend ostream& operator<<(ostream& out, trace t);
};
