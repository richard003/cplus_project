#include<iostream>
#include"LinkList.h"
#include "troop.h"
#include<cstdio>
#include "trace.h"
#include "enemy.h"
#include "game.h"
using namespace std;

char map[Hight][Wight] =
{
	'-','-','-','a','-',
	'-','-','a','-','-',
	'-','-','-','c','-',
	'-','a','-','-','a',
	'-','-','\'','-','-'
};
char actiontype[][20] = { "create","move_up","move_down","move_left","move_right","fighting","dead","victory" };

int main()
{
    void _gametest();
    _gametest();
    system("pause");
    return 0;
}
