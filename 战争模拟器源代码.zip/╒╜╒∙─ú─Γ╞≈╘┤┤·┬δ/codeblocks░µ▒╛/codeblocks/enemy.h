
#pragma once
#include"troop.h"
#define Enemynumber 5
#define Enemy_oringnal_damage 5
#define Enemy_oringnal_health 50
class enemy
{
	double damage;
	double health;
	int level;
	P position;
public:
	static int number;
	enemy(void) { damage = Enemy_oringnal_damage; health = Enemy_oringnal_health; }
	enemy(int x, int y, double damage = Enemy_oringnal_damage, double health = Enemy_oringnal_health);
	void set_pos(int x, int y);
	void set_able(int damage, int health);
	void set_pos(P);
	void set_level(int n);
	P get_pos(void);
	friend troop;
};
enemy* find(P pos);
