#pragma once
#include<iostream>
#include"trace.h"
#include"troop.h"
#include"enemy.h"
#include<Windows.h>
using namespace std;
extern char map[Hight][Wight];
extern char actiontype[][20];
void showmap(void);
void set_enemies(void);